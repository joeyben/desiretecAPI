<?php

return [
    'name' => 'Master',
    'id'   => 7
];
